Copyright (C) 2026 Albert Lamut <albertlamut@gmail.com>
SPDX-License-Identifier: GPL-3.0-or-later
This software is licensed under GNU GPL version 3 or (at your option) any later version. See LICENSE.

Slow Pan Bottom to Top v1.0
1920×1080; frames 0–149.
EN: Copy XML to ~/.local/share/kdenlive/effects/ and restart Kdenlive.
ES: Copia el XML a ~/.local/share/kdenlive/effects/ y reinicia Kdenlive.
